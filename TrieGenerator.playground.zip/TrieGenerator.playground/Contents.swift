import UIKit

class TrieNode {
    var next:[TrieNode] = []
    let alphabet:Character?
    var isword = false
    init(alphabet:Character?){
        self.alphabet = alphabet;
    }

    func search(alphabet:Character) -> TrieNode? {
        for oneNode in next{
            if oneNode.alphabet == alphabet {
                return oneNode;
            }
        }
        return nil;
    }
    
    func addNext(addedNode:TrieNode){
        self.next.append(addedNode)
    }
    
    func setisword(_ isword:Bool){
        self.isword = isword
    }
    
    func writeNode(count:inout Int,outputStream:OutputStream) -> Int{
        count = count + 1
        let mycount = count
        var childcounts:[Int] = []
        var nodeInfo:String = ""
        if self.alphabet == nil {
            nodeInfo = String(mycount) + " nil " + String(self.isword) + " {"
        } else {
            nodeInfo = String(mycount) + " " + String(self.alphabet!) + " " + String(self.isword) + " {"
        }
        
        for childNode in self.next{
            childcounts.append(childNode.writeNode(count:&count,outputStream:outputStream))
        }
        
        let arrayChildCounts = childcounts.map(String.init)
        nodeInfo.append(arrayChildCounts.joined(separator:","))
        nodeInfo.append("}\n")
        outputStream.write(nodeInfo,maxLength:nodeInfo.count)
        return mycount
    }
        
}

func checkIfIsWord(input:String,startNode:TrieNode) -> Bool{
    var currentNode = startNode
    var nextNode:TrieNode?
    for wordAlphabet in input{
        nextNode = currentNode.search(alphabet:wordAlphabet)
        if nextNode == nil{
            return false
        } else {
            currentNode=nextNode!
        }
    }
    if currentNode.isword == true{
        return true
    } else {
        return false
    }
}

let startNode = TrieNode.init(alphabet: nil)
let dictionaryPath = Bundle.main.path(forResource:"Dictionary2", ofType:"txt")
let dictionaryContent = try! String(contentsOfFile:dictionaryPath!, encoding: String.Encoding.utf8)
let dictionary = dictionaryContent.components(separatedBy: CharacterSet.newlines).filter(){$0 != ""}  //the filter can be deleted if unnecessary

dictionary.forEach {
    var currentNode = startNode;
    var nextNode:TrieNode?
    for wordAlphabet in $0{
        nextNode = currentNode.search(alphabet:wordAlphabet)
        if nextNode == nil {
            nextNode = TrieNode.init(alphabet: wordAlphabet)
            currentNode.addNext(addedNode:nextNode!)
        }
        currentNode = nextNode!
    }
    currentNode.setisword(true)
}

//Start Writing Trie to a file
let trieFile = "Trie2.txt"
let URL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!.appendingPathComponent(trieFile)
var count = 0
if let outputStream = OutputStream(url: URL, append: true) {
    outputStream.open()
    startNode.writeNode(count:&count,outputStream:outputStream)
    outputStream.close()
}

