import UIKit

class TrieNode {
    var next:[TrieNode] = []
    let alphabet:Character?
    var isword = false
    init(alphabet:Character?){
        self.alphabet = alphabet;
    }

    func search(alphabet:Character) -> TrieNode? {
        for oneNode in next{
            if oneNode.alphabet == alphabet {
                return oneNode;
            }
        }
        return nil;
    }
    
    func addNext(addedNode:TrieNode){
        self.next.append(addedNode)
    }
    
    func setisword(_ isword:Bool){
        self.isword = isword
    }
}

func checkIfIsWord(input:String,startNode:TrieNode) -> Bool{
    var currentNode = startNode
    var nextNode:TrieNode?
    for wordAlphabet in input{
        nextNode = currentNode.search(alphabet:wordAlphabet)
        if nextNode == nil{
            return false
        } else {
            currentNode=nextNode!
        }
    }
    if currentNode.isword == true{
        return true
    } else {
        return false
    }
}

func saveTrie(count:Int){
    /* save generated Trie to a text file*/
}

let startNode = TrieNode.init(alphabet: nil)
let dictionaryPath = Bundle.main.path(forResource:"LightDictionary", ofType:"txt")
let dictionaryContent = try! String(contentsOfFile:dictionaryPath!, encoding: String.Encoding.utf8)
let dictionary = dictionaryContent.components(separatedBy: CharacterSet.newlines)
dictionary.forEach {
    var currentNode = startNode;
    var nextNode:TrieNode?
    for wordAlphabet in $0{
        nextNode = currentNode.search(alphabet:wordAlphabet)
        if nextNode == nil {
            nextNode = TrieNode.init(alphabet: wordAlphabet)
            currentNode.addNext(addedNode:nextNode!)
        }
        currentNode = nextNode!
    }
    currentNode.setisword(true)
}


